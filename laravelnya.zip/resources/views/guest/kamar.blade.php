@extends('guest.layouts.master')
@section('content')
    <div class="d-flex justify-content-center">
        <h1>KAMAR</h1>
    </div>
    {{-- {{dd($tipe)}} --}}
    <div class="row">
      @foreach ($tipe as $item )
         <div class="col-6">
          <div class="card mb-3 border-radius">
            <img class="card-img-top" style="height: 250px;" src="{{ asset('kamar_image/'. $item->gambar ) }}"
                alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Tipe {{$item->tipe_kamar->nama_tipe}}</h5>
                <p class="card-text">
                    Fasilitas:
                <ul>
                  @php
                 $fasilitas_id =  explode(',',$item->fasilitas_id);
                $fasilitas =   App\Models\Fasilitas::whereIn('id',$fasilitas_id)->get();
                @endphp
                  @foreach ($fasilitas as $item)
                  <li>{{$item->nama_fasilitas}}</li>
                  @endforeach
                </ul>
                </p>
                <p class="card-text"><small class="text-muted">Gambar di ambil dari salah satu kamar yang memiliki tipe kamar tersebut</small></p>
            </div>
        </div>
       
         </div>
      @endforeach

    </div>
    {{-- {{dd($item)}} --}}

@endsection
