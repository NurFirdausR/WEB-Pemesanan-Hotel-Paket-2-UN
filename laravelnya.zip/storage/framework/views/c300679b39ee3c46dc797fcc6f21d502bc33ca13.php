<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center">
        <h1>KAMAR</h1>
    </div>
    
    <div class="row">
      <?php $__currentLoopData = $tipe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-6">
          <div class="card mb-3 border-radius">
            <img class="card-img-top" style="height: 250px;" src="<?php echo e(asset('kamar_image/'. $item->gambar )); ?>"
                alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Tipe <?php echo e($item->tipe_kamar->nama_tipe); ?></h5>
                <p class="card-text">
                    Fasilitas:
                <ul>
                  <?php
                 $fasilitas_id =  explode(',',$item->fasilitas_id);
                $fasilitas =   App\Models\Fasilitas::whereIn('id',$fasilitas_id)->get();
                ?>
                  <?php $__currentLoopData = $fasilitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($item->nama_fasilitas); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                </p>
                <p class="card-text"><small class="text-muted">Gambar di ambil dari salah satu kamar yang memiliki tipe kamar tersebut</small></p>
            </div>
        </div>
       
         </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('guest.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nfr/Documents/laravel/Pemesanan-Hotel-Paket-2-UNv2/resources/views/guest/kamar.blade.php ENDPATH**/ ?>