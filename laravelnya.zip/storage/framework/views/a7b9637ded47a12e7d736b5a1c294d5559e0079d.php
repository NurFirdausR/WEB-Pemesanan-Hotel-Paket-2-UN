<?php $__env->startSection('content'); ?>

<div class="main-content">
    <section class="section">
      <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6 col-12">
          <div class="card card-statistic-1">
            <div class="card-icon bg-primary">
              <i class="far fa-user"></i>
            </div>
            <div class="card-wrap">
              <div class="card-header">
                <h4>Jumlah Tipe Kamar</h4>
              </div>
              <div class="card-body">
                <?php echo e($total_tipe_kamar); ?>

              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-12">
          <div class="card card-statistic-1">
            <div class="card-icon bg-danger">
              <i class="far fa-newspaper"></i>
            </div>
            <div class="card-wrap">
              <div class="card-header">
                <h4>Jumlah Kamar</h4>
              </div>
              <div class="card-body">
                <?php echo e($total_kamar); ?>


              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-12">
          <div class="card card-statistic-1">
            <div class="card-icon bg-warning">
              <i class="far fa-file"></i>
            </div>
            <div class="card-wrap">
              <div class="card-header">
                <h4>Jumlah Fasilitas Umum</h4>
              </div>
              <div class="card-body">
                <?php echo e($total_fasilitas_umum); ?>


              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-12">
          <div class="card card-statistic-1">
            <div class="card-icon bg-success">
              <i class="fas fa-circle"></i>
            </div>
            <div class="card-wrap">
              <div class="card-header">
                <h4>Jumlah Fasilitas Kamar</h4>
              </div>
              <div class="card-body">
                <?php echo e($total_fasilitas_kamar); ?>


              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="d-flex justify-content-center">
        <div class="col-lg-6 col-md-6 col-sm-6 col-12 justi">
          <div class="card card-statistic-1">
            <div class="card-icon bg-success">
              <i class="fas fa-circle"></i>
            </div>
            <div class="card-wrap">
              <div class="card-header">
                <h4>Jumlah Pendapatan</h4>
              </div>
              <div class="card-body">
                Rp
                <?php echo e($total_pendapatan); ?>


              </div>
            </div>
          </div>
        </div>
      </div>
      
    </section>
  </div>
 
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nfr/Documents/laravel/Pemesanan-Hotel-Paket-2-UNv2/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>