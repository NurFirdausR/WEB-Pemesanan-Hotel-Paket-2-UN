<?php $__env->startPush('style'); ?>
              
             <link rel="stylesheet" href="<?php echo e(asset('fasilitass')); ?>/css/style.css">
             

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?> 

<div class="d-flex justify-content-center">
    <h1>FASILITAS</h1>
</div>
<div class="container"  >
    <div class="row">
        <?php $__currentLoopData = $fasilitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 col-sm-6 p-2">
            <div class="box">
                <img src="<?php echo e(asset('fasilitas_image/'.$item->gambar)); ?>" style="width: 100%; height: 250px;">
                <div class="box-content">
                    <div class="inner-content">
                        <h3 class="title"><?php echo e($item->nama_fasilitas); ?></h3>
                        <span class="post">Fasilitas: <?php echo e($item->tipe_fasilitas); ?></span>
                    </div>
                </div>
            </div>
        </div>
      
        
        
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('guest.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nfr/Documents/laravel/Pemesanan-Hotel-Paket-2-UNv2/resources/views/guest/fasilitas.blade.php ENDPATH**/ ?>