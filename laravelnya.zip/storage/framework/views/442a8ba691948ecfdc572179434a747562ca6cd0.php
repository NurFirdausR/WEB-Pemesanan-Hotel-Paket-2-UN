<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('step_content'); ?>
    <div class="card">
        <div class="card-body">
            <h4> Ketersediaan Kamar</h4>
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <?php $__empty_1 = true; $__currentLoopData = $kamar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link " id="<?php echo e($loop->iteration); ?>-tab" data-bs-toggle="tab"
                            data-bs-target="#kamar<?php echo e($loop->iteration); ?>" type="button" role="tab"
                            aria-controls="<?php echo e($loop->iteration); ?>" aria-selected="false"><?php echo e($item->nama_kamar); ?></button>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>


            </ul>
            <div class="tab-content" id="myTabContent">

                <?php $__empty_1 = true; $__currentLoopData = $kamar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $unbooked_kamar = App\Models\Kamar::where('nama_kamar', $item->nama_kamar)
                            ->where('status', 'unbooked')
                            ->get()
                            ->unique('code_kamar');
                    ?>
                    <div class="tab-pane fade" id="kamar<?php echo e($loop->iteration); ?>" role="tabpanel"
                        aria-labelledby="<?php echo e($loop->iteration); ?>-tab">
                        <?php $__empty_2 = true; $__currentLoopData = $unbooked_kamar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                            <div class="card mb-3" >
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="<?php echo e(asset('kamar_image')); ?>/<?php echo e($item->gambar); ?>"
                                            class="img-fluid rounded" style="height: 200px; width: 250px;" alt="...">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="card-body">
                                            <h5 class="card-title text-dark font-bolder"><?php echo e($item->nama_kamar); ?></h5>

                                            <div class="row">
                                                <div class="col-6">
                                                    <p class="card-text text-dark">Maks orang : <?php echo e($item->maks_orang); ?></p>
                                                </div>
                                                <div class="col-6">
                                                    <p class="card-text text-dark">Tipe Kamar : <?php echo e($item->tipe_kamar->nama_tipe); ?>

                                                </div>
                                            </div>
                                            <p class="card-text text-dark">Harga : <?php echo e(rupiah( $item->harga)); ?>

                                            </p>
                                            <button class="btn btn-sm btn-success pesan"
                                                data-id="<?php echo e($item->id); ?>">Book Now</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="d-flex justify-content-center">
                        <h2 class="text-danger">
                            Data Kamar Tidak di temukan!
                        </h2>
                    </div>
                <?php endif; ?>
            </div>
            <div class="card">
                <div class="card-body">

                    <a class="btn btn-warning" href="<?php echo e(route('pemesanan_step_one')); ?>">Previous</a>
                    <a class="btn btn-primary" href="<?php echo e(route('pemesanan_step_three')); ?>">Next</a>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.pesan').click(function(e) {
                e.preventDefault();

                var kamar_id = $(this).attr('data-id')


                console.log(kamar_id)

                var token = document.head.querySelector('meta[name="csrf-token"]');
                window.axios.defaults.headers.common['X-CSRF-TOKEN'] = token.content;

                axios.post("<?php echo e(route('pemesanan_step_two.store')); ?>", {
                        kamar_id: kamar_id,


                    }, {
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': token.content,
                            'X-Requested-With': 'XMLHttpRequest',
                        }
                    })
                    .then(function(response) {
                        console.log(response);
                        location.reload();

                    })
                    .catch(function(error) {
                        console.log(error)

                    });

            });



        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('guest.layouts.master_step', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nfr/Documents/laravel/Pemesanan-Hotel-Paket-2-UNv2/resources/views/guest/pemesanan_step_two.blade.php ENDPATH**/ ?>